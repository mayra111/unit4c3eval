const express = require("express");
const mongoose = require("mongoose");


const app = express();
app.use(express.json());

const connect = () => {
    return mongoose.connect(
      "mongodb+srv://muskan:<password>@cluster0.l4ev6.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"
    );
  };

const userSchema = new mongoose.Schema(
    {
      firstName: { type: String, required: true },
      lastName: { type: String, required: false },
      age: { type: String, required: true },
      email: { type: String, required: true, unique: true },
      profileImages: { type: String, required: true },

      password: { type: String, required: true },
    },
    {
      versionKey: false,
      timestamps: true, // createdAt, updatedAt
    }
  );
  
  // Step 2 : creating the model
  const User = mongoose.model("user", userSchema); // user => users

  const bookSchema = new mongoose.Schema(
    {
        likes: { type: Number, required: true },
        coverImage: { type: String, required: true },
        content: { type: String, required: true },
     
    },
    {
      versionKey: false,
      timestamps: true, // createdAt, updatedAt
    }
  );
  
  // Step 2 :- creating the model
  const Post = mongoose.model("book", bookSchema); // post => 


  const commentSchema = new mongoose.Schema(
    {
      body: { type: String, required: true },
     
    },
    {
      versionKey: false,
      timestamps: true,
    }
  );
  
  // Step 2 :- creating the model
  const Comment = mongoose.model("comment", commentSchema); // comment => comments



  app.get("/users", async (req, res) => {
    try {
      const users = await User.find().lean().exec();
  
      return res.status(200).send({ users: users }); // []
    } catch (err) {
      return res
        .status(500)
        .send({ message: "Something went wrong .. try again later" });
    }
  });
  
  app.post("/users", async (req, res) => {
    try {
      const user = await User.create(req.body);
  
      return res.status(201).send(user);
    } catch (err) {
      return res.status(500).send({ message: err.message });
    }
  });
    
  
  app.get("/users/:id", async (req, res) => {
    try {
      const user = await User.findById(req.params.id).lean().exec();
      // db.users.findOne({_id: Object('622893471b0065f917d24a38')})
  
      return res.status(200).send(user);
    } catch (err) {
      return res.status(500).send({ message: err.message });
    }
  });
  
  app.patch("/users/:id", async (req, res) => {
    try {
      const user = await User.findByIdAndUpdate(req.params.id, req.body, {
        new: true,
      })
        .lean()
        .exec();
      // db.users.update({_id: Object('622893471b0065f917d24a38')}, {$set: {req.body}})
  
      return res.status(200).send(user);
    } catch (err) {
      return res.status(500).send({ message: err.message });
    }
  });
  
  app.delete("/users/:id", async (req, res) => {
    try {
      const user = await User.findByIdAndDelete(req.params.id).lean().exec();
      // db.users.deleteOne({_id: Object('622893471b0065f917d24a38')})
  
      return res.status(200).send(user);
    } catch (err) {
      return res.status(500).send({ message: err.message });
    }
  });
  
  // POSTS CRUD
  app.get("/book", async (req, res) => {
    try {
      const posts = await Post.find().lean().exec();
  
      return res.status(200).send(posts);
    } catch (err) {
      return res.status(500).send({ message: err.message });
    }
  });
  
  app.post("/book", async (req, res) => {
    try {
      const post = await Post.create(req.body);
  
      return res.status(200).send(post);
    } catch (err) {
      return res.status(500).send({ message: err.message });
    }
  });
  
  app.get("/post/:id", async (req, res) => {
    try {
      const post = await Post.findById(req.params.id).lean().exec();
  
      return res.status(200).send(post);
    } catch (err) {
      return res.status(500).send({ message: err.message });
    }
  });
  
  app.patch("/post/:id", async (req, res) => {
    try {
      const post = await Post.findByIdAndUpdate(req.params.id, req.body, {
        new: true,
      })
        .lean()
        .exec();
  
      return res.status(200).send(post);
    } catch (err) {
      return res.status(500).send({ message: err.message });
    }
  });
  
  app.delete("/post/:id", async (req, res) => {
    try {
      const post = await Post.findByIdAndDelete(req.params.id).lean().exec();
  
      return res.status(200).send(post);
    } catch (err) {
      return res.status(500).send({ message: err.message });
    }
  });


app.listen(5000, async () => {
    try {
      await connect();
    } catch (err) {
      console.log(err);
    }
  
    console.log("listening on port 5000");
  });
  